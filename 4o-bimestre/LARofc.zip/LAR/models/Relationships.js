const Restaurantes = require('./Restaurantes');
const Cardapio = require('./Cardapio');
const Categoria = require('./Categoria');
const Itens = require('./Itens');
const Chefes = require('./Chefes');
const Cliente = require('./Cliente');
const Fdp = require('./Fdp');


module.exports = () => {
  // 1-1: User -> Profile
  // User.hasOne(Profile, { foreignKey: 'userId' });
  // Profile.belongsTo(User, { foreignKey: 'userId' });

  // 1-N: User -> Post
  Restaurantes.hasMany(Cardapio, { foreignKey: 'cnpj' });
  Cardapio.belongsTo(Restaurantes, { foreignKey: 'cnpj' });

  Categoria.hasMany(Cardapio, { foreignKey: 'cod' });
  Cardapio.belongsTo(Categoria, { foreignKey: 'cod' });

  Itens.hasMany(Categoria, { foreignKey: 'cod' });
  Categoria.belongsTo(Itens, { foreignKey: 'cod' });

  // N-M: Post <-> Tag
  Cliente.belongsToMany(Restaurantes, { through: clienterestaurantes });
  Restaurantes.belongsToMany(Cliente, { through: clienterestaurantes });

  Chefes.belongsToMany(Restaurantes, { through: chefesrestaurantes });
  Restaurantes.belongsToMany(Chefes, { through: chefesrestaurantes });

 Fdp.belongsToMany(Cliente, { through: compras });
 Cliente.belongsToMany(Fdp, { through: compras });

compras.belongsTo(Cliente, { foreignKey: 'nome' });
compras.belongsTo(Fdp, { foreignKey: 'cod' });
compras.belongsTo(Itens, { foreignKey: 'cod' });
compras.belongsTo(Restaurantes, { foreignKey: 'cnpj' });

Cliente.hasMany(compras, { foreignKey: 'nome' });
Fdp.hasMany(compras, { foreignKey: 'cod' });
Itens.hasMany(compras, { foreignKey: 'cod' });
Restaurantes.hasMany(compras, { foreignKey: 'cnpj' });
};

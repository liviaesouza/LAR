const Restaurantes = require('./restaurantes');
const Cardapio = require('./Cardapio');
const Categoria = require('./Categoria');
const Itens = require('./Itens');
const Chefes = require('./Chefes');
const Cliente = require('./Cliente');

module.exports = () => {
  // 1-1: User -> Profile
  // User.hasOne(Profile, { foreignKey: 'userId' });
  // Profile.belongsTo(User, { foreignKey: 'userId' });

  // 1-N: User -> Post
  restaurantes.hasMany(cardapio, { foreignKey: 'cnpj' });
  cardapio.belongsTo(restaurantes, { foreignKey: 'cnpj' });

  categoria.hasMany(cardapio, { foreignKey: 'cod' });
  cardapio.belongsTo(categoria, { foreignKey: 'cod' });

  itens.hasMany(categoria, { foreignKey: 'cod' });
  categoria.belongsTo(itens, { foreignKey: 'cod' });

  // N-M: Post <-> Tag
  cliente.belongsToMany(restaurantes, { through: clienterestaurantes });
  restaurantes.belongsToMany(cliente, { through: clienterestaurantes });

  chefes.belongsToMany(restaurantes, { through: chefesrestaurantes });
  restaurantes.belongsToMany(chefes, { through: chefesrestaurantes });

 fdp.belongsToMany(cliente, { through: compras });
 cliente.belongsToMany(fdp, { through: compras });

compras.belongsTo(cliente, { foreignKey: 'nome' });
compras.belongsTo(fdp, { foreignKey: 'cod' });
compras.belongsTo(itens, { foreignKey: 'cod' });
compras.belongsTo(restaurantes, { foreignKey: 'cnpj' });

cliente.hasMany(compras, { foreignKey: 'nome' });
fdp.hasMany(compras, { foreignKey: 'cod' });
itens.hasMany(compras, { foreignKey: 'cod' });
restaurantes.hasMany(compras, { foreignKey: 'cnpj' });
};

const Restaurantes = require('./models/restaurantes');
const Cardapio = require('./models/cardapio');
const Categoria = require('./models/categoria');
const Chefes = require('./models/chefes');
const Cliente = require('./models/cliente');
const Itens = require('./models/itens');
const setupRelationships = require('./models/Relationships');

(async () => {
  try {
    // Configurar relacionamentos
    setupRelationships();

    // Sincronizar o banco de dados
    await sequelize.sync({ force: true });
    console.log('Banco de dados sincronizado.');

    // Criar um usuário
    const restaurantes = await Restaurantes.create({
    cnpj: '11.111.111/0001-11',
    tele: '(82)9888-8888',
    nomeFantasia: 'Donacindi',
    nome: 'Donacindi-Woodsen',
    horario: '18:00-00:00',
    logo: 'www.logo',
    endereco: 'Messias',
    foto: 'www.foto',
    email: 'donac@email.com',
    senha: 'donac123',
    taxa: '150'
    });

    const cliente = await Cliente.create({
      nome: 'Scofield',
      nomeUsuario: 'Scofield26',
      sexo: 'masculino',
      fotoPerfil: 'perfil1',
      nasc: '2000-07-22',
      tele: '88888800',
      endereco: 'Rio-Largo',
      email: 'michael@email.com',
      senha: 'Ranny123',
      });

    const itens = await Itens.create({
      nome: 'coxinha',
      foto: 'foto1',
      descricao: 'desc1',
      preco: '20',
    });

    console.log('Usuário e perfil criados:', user.toJSON(), profile.toJSON());

    // Criar posts
    const categoria = await Categoria.create({
      cod: '96758',
      nome: 'entrada',
      
    });

    const chefes = await Chefes.create({
      senha: 'justnormal',
      foto: 'foto1',
      nome: 'maria',
      sexo: 'feminino',
      nomeUsuario: 'maria22',
      avaliacao: '4,0',
      nasc: '2000-07-26',
      email: 'mari@email.com',
      curriculo: 'curric1',
      tele: '9836456',
      taxa: '110'
      
    });
    // Criar tags
    const tag1 = await Tag.create({ name: 'Tecnologia' });
    const tag2 = await Tag.create({ name: 'Programação' });

    console.log('Tags criadas:', tag1.toJSON(), tag2.toJSON());

    // Associar tags aos posts com atributos extras
    await post1.addTag(tag1, { through: { relevance: 5 } });
    await post1.addTag(tag2, { through: { relevance: 3 } });
    await post2.addTag(tag2, { through: { relevance: 4 } });

    console.log('Tags associadas aos posts.');

    // Consultar posts com tags
    const posts = await Post.findAll({
      include: {
        model: Tag,
        through: { attributes: ['assignedAt', 'relevance'] },
      },
    });

    console.log('Posts com tags:', JSON.stringify(posts, null, 2));
  } catch (error) {
    console.error('Erro ao sincronizar o banco de dados:', error);
  }
})();

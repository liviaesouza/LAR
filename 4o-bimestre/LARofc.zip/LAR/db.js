const {Sequelize} = require('sequelize');
const sequelize = new Sequelize(
    'LAR', // nome do banco
    '', // nome do usuario
    '', // senha de acesso
    {
        host: 'localhost',
        dialect: 'mysql'
    }
);
module.exports = sequelize;
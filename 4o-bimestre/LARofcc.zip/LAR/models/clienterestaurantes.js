const { DataTypes } = require('sequelize');
const sequelize = require('../db');
const Cliente = require('./Cliente'); // Importando o modelo Cliente
const Restaurante = require('./Restaurantes'); // Importando o modelo Restaurante

// Definindo o modelo intermediário 'clienterestaurantes'
const ClienteRestaurantes = sequelize.define('clienterestaurantes', {
  clienteId: {
    type: DataTypes.STRING,  // Definindo como STRING, já que 'nome' é STRING no Cliente
    references: {
      model: Cliente,
      key: 'nome'  // A chave primária de 'Cliente' é 'nome'
    }
  },
  restauranteId: {
    type: DataTypes.STRING,  // Definindo como STRING, já que 'cnpj' é STRING no Restaurante
    references: {
      model: Restaurante,
      key: 'cnpj'  // A chave primária de 'Restaurante' é 'cnpj'
    }
  }
});

module.exports = ClienteRestaurantes;
